package com.atguigu.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Boot09FeaturesProfileApplicationTests {

    @Test
    void contextLoads() {
    }

}

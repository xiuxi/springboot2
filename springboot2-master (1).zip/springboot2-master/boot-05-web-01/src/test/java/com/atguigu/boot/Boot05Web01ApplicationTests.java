package com.atguigu.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class Boot05Web01ApplicationTests {

    @Test
    void contextLoads() {

    }

}
